#include <iostream>
#include <string>
using namespace std;

int s1[9] = { 0,1,1,1,2,2,4,5,1 };//�[�_�ӥ���

int s2[9] = { 0,2,3,2,3,4,1,5,4 };//�Ĥ@�ӼƦr
int s3[9] = { 0,1,4,3,4,2,2,5,4 };//�ĤG�ӼƦr

bool num[9] = { 0,1,0,0,0,0,1,0,0 };//�P�_�`��
bool is[46] = { 0 };//�P�_�]�Lissue�F�S
char cycle[9] = { ' ' ,'+' ,'-' ,'/' ,'*' ,'+' ,'+','*','+' };//�C�ӲŸ�

string RF[6] = { "0","0","2","4","6","8" };//�_�lRF��

string RAT[6] = { " " };//�_�lRAT��

string RS[6][6] = { " " };//�_�lRS��
string RSIndex[6] = { " ","RS1","RS2", "RS3", "RS4", "RS5" };//RS��Index �Ω�s�bRAT

int Cycle = 1;//�`�W �ΨӶ]�A��total Cycle
int Cycle2 = Cycle;//�]+ -
int Cycle3 = Cycle;//�]* /

bool Cycle_issue[46] ;
bool Cycle_Dispatch1[59] = { 0 };
int Inst_Sym1[59] = { 0 };//�N���A�O+-*/���@��         1����+-�k���F��    2����*/
int Inst_Sym2[55] = { 0 };

string BufferState1 = "empty";
string BufferState2 = "empty";

string T = "(",T1=") ";

int RATValue[6] = { 0 };

void PlayRF() {
	cout << "   _ RF __" << endl;
	cout << "F1 |   " << RF[1] << " | "<<endl;
	cout << "F2 |   " << RF[2] << " | " << endl;
	cout << "F3 |   " << RF[3] << " | " << endl;
	cout << "F4 |   " << RF[4] << " | " << endl;
	cout << "F5 |   " << RF[5] << " | " << endl;
	cout << "   -------" << endl << endl;
}

void playRAT() {
	cout << "   _ RAT __" << endl;
	cout << "F1 |   " << RAT[1] << " | " << endl;
	cout << "F2 |   " << RAT[2] << " | " << endl;
	cout << "F3 |   " << RAT[3] << " | " << endl;
	cout << "F4 |   " << RAT[4] << " | " << endl;
	cout << "F5 |   " << RAT[5] << " | " << endl;
	cout << "   -------" << endl << endl;
}

void playRS() {
	cout << "    _ RS _________________" << endl;
	cout << "RS1 |    " << RS[1][0] << " |    " << RS[1][1] << " |    " << RS[1][2] << " |" << endl;
	cout << "RS2 |    " << RS[2][0] << " |    " << RS[2][1] << " |    " << RS[2][2] << " |" << endl;
	cout << "RS3 |    " << RS[3][0] << " |    " << RS[3][1] << " |    " << RS[3][2] << " |" << endl;
	cout << "    ----------------------" << endl;
	cout << "BUFFER: " << BufferState1 << endl;
	cout << "RS4 |    " << RS[4][0] << " |    " << RS[4][1] << " |    " << RS[4][2] << " |" << endl;
	cout << "RS5 |    " << RS[5][0] << " |    " << RS[5][1] << " |    " << RS[5][2] << " |" << endl;
	cout << "    ----------------------" << endl;
	cout << "BUFFER: " << BufferState2 << endl << endl;
}

void issue(char a,int C) {
	bool t = 0;
	if (a == '+' || a == '-') {
		for (int i = 1; i <= 3; i++) {
			if (t == 1)
				break;
			if (RS[i][0] == "") {
				RS[i][0] = cycle[Cycle];//�ˬd�Ÿ�
				if (RAT[s2[C]] == "")
					RS[i][1] = RF[s2[C]];
				else
					RS[i][1] = RAT[s2[C]];//�ˬd��1�ӼƦr

				if (num[C] == true)//��2�ӼƦr�|���`�ư��D
					RS[i][2] = to_string(s3[C]);
				else {
					if (RAT[s3[C]] == "")
						RS[i][2] = RF[s3[C]];
					else
						RS[i][2] = RAT[s3[C]];
				}//�ˬd��2��
				RAT[s1[C]] = RSIndex[i];
				is[C] = 0;
				t = 1;
			}
		}
	}
	else {
		for (int i = 4; i <= 5; i++) {
			if (RS[i][0] == "") {
				if (t == 1)
					break;
				RS[i][0] = cycle[Cycle];//�Ÿ�

				if (RAT[s2[C]] == "")
					RS[i][1] = RF[s2[C]];
				else
					RS[i][1] = RAT[s2[C]];//�ˬd��1�ӼƦr

				if (RAT[s3[C]] == "")
					RS[i][2] = RF[s3[C]];
				else
					RS[i][2] = RAT[s3[C]];//�ˬd��2��
				RAT[s1[C]] = RSIndex[i];
				is[C] = 0;
				t = 1;
			}
		}
	}
}
int Dispatch1(int a, int C) {
	bool t = 0;
		for (int i = 1; i <= 3; i++) {
			if (RS[i][0] != " "&&RS[i][1].length() < 3 && RS[i][2].length() < 3) {//���F��åB���s�Ʀr
				if (t == 1) {
					return C;
					break;
				}
				BufferState1 = T + RSIndex[i] + T1 + RS[i][1];
				if (a == 1) {
					BufferState1 += " + " + RS[i][2];
					C += 2;
				}
				else {
					BufferState1 += " - " + RS[i][2];//��BufferState
					C += 2;
				}
				t = 1;
			}
		}
}
int Dispatch2(int a, int C){
	bool t = 0;
	for (int i = 4; i <= 5; i++) {
		if (RS[i][0] != " "&&RS[i][1].length() < 3 && RS[i][2].length() < 3) {//���F��åB���s�Ʀr
			if (t == 1) {
				return C;
				break;
			}
			BufferState2 = T + RSIndex[i] + T1 + RS[i][1];
			if (a == 3) {
				BufferState2 += " * " + RS[i][2];
				C += 10;
			}
			else {
				BufferState2 += " / " + RS[i][2];//��BufferState
				C += 40;
			}
			t = 1;
		}
	}
}

void WriteBack(int C) {

}

int main() {

	int temp = 0;
	int count = 1;
	is[1] = is[2] = is[3] = is[4] = is[5] = is[6] = is[44] = is[45] = 1;
	Cycle_issue[1] = Cycle_issue[2] = Cycle_issue[3] = Cycle_issue[4] = Cycle_issue[5] = Cycle_issue[6] = Cycle_issue[44] = Cycle_issue[45] = true;
	//�]issue��cycle��
	Inst_Sym1[2] = Inst_Sym1[54] = Inst_Sym1[56] = Inst_Sym1[58] = 1;// +
	Inst_Sym1[4] = 2;// -
	Inst_Sym2[44] = Inst_Sym2[54] = 3;// *
	Inst_Sym2[4] = 4;// '/'

	Cycle_Dispatch1[2] = Cycle_Dispatch1[54] = Cycle_Dispatch1[56] = Cycle_Dispatch1[58] = 1;
	int Inst = 1;

	while (Cycle <= 64) {
		temp = Cycle;
		cout << "Cycle :" << Cycle << endl;
		if (is[Cycle] == 1 && Inst <= 8) {
			Cycle = Inst;
			issue(cycle[Cycle], Cycle);//�Ÿ� �ĴX��Cycle
			Cycle = temp;
			Inst++;
		}//ISSUE

		if (Cycle > 1 && Inst_Sym1[Cycle] != 0 || Inst_Sym2[Cycle] != 0) {//(���Ÿ�=    !=0�n��Dispatch �ҥH�L�|�i���ɭԬO 2 4 4 44 54 56 54 58
			if (Inst_Sym1[Cycle] != 0) {
				Cycle2 = Dispatch1(Inst_Sym1[Cycle], Cycle);

			}
			if (Inst_Sym2[Cycle] != 0) {
				Cycle3 = Dispatch2(Inst_Sym2[Cycle], Cycle);
			}
		}

		if (Cycle >= 4 && Cycle == Cycle2) {

		}
		if (Cycle >= 4 && Cycle == Cycle3) {

		}

		Cycle++;

		PlayRF();
		playRAT();
		playRS();
	}

}