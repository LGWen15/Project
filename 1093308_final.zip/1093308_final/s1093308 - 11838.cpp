#include <iostream>
#include <vector>
#include <stack>
#include <algorithm>
#include <cstring>
using namespace std;

const int maxNumNodes = 2005;
vector< int > adjList[ maxNumNodes ]; // the adjacency list of the given graph
int d[ maxNumNodes ];
int low[ maxNumNodes ];
int dfsTime;
stack< int > nodeStack;      // a stack of nodes
bool inStack[ maxNumNodes ]; // inStack[ u ] is true if and only if node u is in nodeStack
int numSCCs;                 // the numbers of strongly connected components of the given graph

// implement Tarjan's strongly component algorithm
// compute numSCCs
void tarjanSCC( int u )
{
    d[ u ] = low[ u ] = ++dfsTime;
    nodeStack.emplace( u );
    inStack[ u ] = true;
    for( auto&v : adjList[ u ] ) {
        if( d[ v ]==0 ) {
            tarjanSCC( v );
            low[ u ] = min( low[ u ], low[ v ] );
        }
        else if( inStack[ v ] )
            low[ u ] = min( low[ u ], d[ v ] );
    }
    if( low[ u ] == d[ u ]) {
        int w;
        do { 
            w = nodeStack.top();
            nodeStack.pop();
            inStack[ w ] = false;
        }
        while( w != u );
        numSCCs++;
    }

}

int main() {
	int n, m;
	while( cin >> n >> m && ( n && m ) ) {


        int s, t, p, maxNodeID = 0;
        memset( d, 0, sizeof( d ) );
        memset( low, 0, sizeof( low ) );
        memset( inStack, false, sizeof( inStack ) );
        for( int i = 0; i < m; i++ )
        {
            cin >> s >> t>>p;
            if( p == 1 )
                adjList[ s ].emplace_back(t);
            else {
                adjList[ s ].emplace_back( t );
                adjList[ t ].emplace_back( s );
            }
            maxNodeID = max( maxNodeID, s );
            maxNodeID = max( maxNodeID, t );
        }
        dfsTime = 0;
        numSCCs = 0;

        for( int i = 1; i <= maxNodeID; i++ )
            if( d[ i ] == 0 )
                tarjanSCC( i );

        if( numSCCs > 1 )
            cout << "0" << endl;
        else
            cout << "1" << endl;
        for( int i = 0; i <= n; i++ )
            adjList[ i ].clear();

	}
}